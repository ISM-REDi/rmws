import EventsPage from './pages/EventsPage'

function App() {
  return <EventsPage />
}

export default App
